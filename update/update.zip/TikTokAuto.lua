----------------------------------------------------------------
-- 🎬 TikTok AutoFlow v8.5p-DeleteFlowIntegrated_v1.8 (CÁCH A)
-- ✅ ACC-FLOW (từng tài khoản): follow → like → comment → share
-- ✅ POST-FLOW (từng bài đăng): like → comment → share
-- ✅ delete → download → upload → growvideo (sau cùng)
-- 🧠 Safe Delay / Auto Kill / Stable Log / DeleteFlow / GrowVideo
-- By Mr.L + Custom DRX (arrow.png random video)
----------------------------------------------------------------

local curl = require("cURL")

----------------------------------------------------------------
-- 🪪 CONFIGURATION
----------------------------------------------------------------
local jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJla2s4OSIsImxldmVsIjo5OSwiZnVsbF9uYW1lIjoiTG9uZyIsInVzZXJfaWQiOjEzLCJsYXN0X3RpbWVfcHciOjAsImlhdCI6MTc2MzcwODc2NX0.2dY-917FIiSpGj8tg8PmjN2KNHUvO4kLo44ojT1RZpo"
local deviceID = "K10"
local hostName = "https://api.drxcloudphone.com"
local apiGet   = hostName .. "/api/v1/tool/action/get?action_type=tiktok&jwt=" .. jwt .. "&device_id=" .. deviceID

-- Shortcuts/Assets
local shortcutSave   = "AutoSaveVideo"
local shortcutDelete = "DeletePhotos"
local imgPath        = rootDir() .. "/img/"
local fixedURL       = "http://file.fms-router.com:9999/data/tiktok2/2.mp4"

----------------------------------------------------------------
-- ⚙️ UTILITIES
----------------------------------------------------------------
local function sleep2() usleep(2000000) end
local function sleep3() usleep(3000000) end
local function sleep4() usleep(4000000) end
local function sleep5() usleep(5000000) end
local function sleep7() usleep(7000000) end
local function sleep9() usleep(9000000) end
local function delayKill() usleep(5000000) end
local function delayLog() usleep(5000000) end

local function tap(x, y, delay)
    if not x or not y then return end
    touchDown(1, x, y)
    usleep(85000)
    touchUp(1, x, y)
    usleep(delay or 1000000)
end

local function findImgRetry(name, thr, retries)
    local threshold = thr or 0.4
    local fullPath  = imgPath .. name
    retries = retries or 3

    for i = 1, retries do
        toast("🔍 Tìm ảnh: " .. name .. " (lần " .. i .. ")")
        local r = findImage(fullPath, 1, threshold, nil, false, 2)
        if r and #r > 0 then
            local x, y = r[1][1], r[1][2]
            toast("✅ " .. name .. " tại [" .. math.floor(x) .. "," .. math.floor(y) .. "]")
            return x, y
        end
        usleep(800000)
    end

    toast("❌ Không thấy " .. name .. " sau " .. retries .. " lần")
    return nil, nil
end

local function getBasePlus()
    local x, y = findImgRetry("whiteplus.png", 0.4, 3)
    if x and y then return x, y end
    toast("⚠️ Fallback whiteplus → (381,1283)")
    return 381, 1283
end

local function openURLSafe(url)
    pcall(function()
        if type(openURL) == "function" then
            openURL(url)
        else
            require "objc"
            local NSURL         = objc.NSURL
            local UIApplication = objc.UIApplication
            UIApplication:sharedApplication():openURL_(NSURL:URLWithString_(url))
        end
    end)
    sleep4()
end

----------------------------------------------------------------
-- 🌐 SERVER LOG
----------------------------------------------------------------
local function sendLog(actionId, logText, statusCode)
    if not actionId then
        toast("⚠️ Thiếu _id, bỏ qua log")
        return
    end

    local apiLog = string.format("%s/api/v1/tool/action/%s?jwt=%s", hostName, actionId, jwt)
    local body   = string.format('{"log":"%s","status":%d}', logText, statusCode)
    local resp   = ""

    local ok, err = pcall(function()
        local c = curl.easy{
            url           = apiLog,
            postfields    = body,
            customrequest = "PUT",
            httpheader    = {"Content-Type: application/json"},
            ssl_verifypeer = false,
            ssl_verifyhost = false,
            timeout        = 15,
            writefunction  = function(s) resp = resp .. s return #s end
        }
        c:perform()
        c:close()
    end)

    if not ok then
        toast("❌ Lỗi gửi log: " .. tostring(err))
    else
        local code = resp:match('"code"%s*:%s*(%d+)') or "???"
        toast(string.format("📤 PUT Log [%d] – %s (code:%s)", statusCode, logText, code))
    end
end

----------------------------------------------------------------
-- 🛰️ API GET
----------------------------------------------------------------
local function getAPIResponse()
    local response = ""
    local c = curl.easy{
        url            = apiGet,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction  = function(s) response = response .. s return #s end
    }
    pcall(function() c:perform() end)
    c:close()
    return response
end

----------------------------------------------------------------
-- 🧠 PARSE RESPONSE
----------------------------------------------------------------
local ORDER = {
    "follow","like","share","comment",
    "deletevideo","downloadvideo","postvideo","uppost","growvideo"
}

local function sortActions(actions)
    table.sort(actions, function(a, b)
        local ia, ib = 999, 999
        for i, v in ipairs(ORDER) do
            if v == a then ia = i end
            if v == b then ib = i end
        end
        return ia < ib
    end)
    return actions
end

local function parseWatchDuration(raw)
    local minW, maxW = 5, 10
    if not raw or raw == "" then return minW, maxW end

    if raw:find("%-") then
        local a, b = raw:match("(%d+)%-(%d+)")
        if a and b then
            minW, maxW = tonumber(a) or 5, tonumber(b) or 10
            if minW > maxW then minW, maxW = maxW, minW end
        end
    else
        local v = tonumber(raw)
        if v then minW, maxW = v, v end
    end

    minW = math.max(1, math.floor(minW))
    maxW = math.max(minW, math.floor(maxW))
    return minW, maxW
end

local function extractOptions(resp)
    if not resp or resp == "" then return nil end

    local id = resp:match('"_id"%s*:%s*"(.-)"')
    if not id then
        toast("⚠️ Không tìm thấy _id trong phản hồi")
        return nil
    end

    local actions, linkAcc, linkPost, commentContent = {}, {}, {}, {}

    for a in resp:gmatch('"actions"%s*:%s*%[(.-)%]') do
        for v in a:gmatch('"(.-)"') do
            table.insert(actions, v:lower())
        end
    end
    actions = sortActions(actions)

    for b in resp:gmatch('"linkAcc"%s*:%s*%[(.-)%]') do
        for v in b:gmatch('"(.-)"') do
            table.insert(linkAcc, v)
        end
    end

    for c in resp:gmatch('"linkPost"%s*:%s*%[(.-)%]') do
        for v in c:gmatch('"(.-)"') do
            table.insert(linkPost, v)
        end
    end

    -- xoá phần tử linkPost rỗng để tránh lỗi
    for i = #linkPost, 1, -1 do
        if not linkPost[i] or linkPost[i] == "" or linkPost[i] == " " then
            table.remove(linkPost, i)
        end
    end

    for d in resp:gmatch('"commentContent"%s*:%s*%[(.-)%]') do
        for v in d:gmatch('"(.-)"') do
            table.insert(commentContent, v)
        end
    end

    local delay          = tonumber(resp:match('"delaySec"%s*:%s*(%d+)')) or 5
    local scrollCountRaw = resp:match('"scrollCount"%s*:%s*"(.-)"') or resp:match('"scrollCount"%s*:%s*(%d+)')
    local scrollCount    = tonumber(scrollCountRaw) or 3
    local watchDuration  = resp:match('"watchDuration"%s*:%s*"(.-)"') or ""
    local minWatch, maxWatch = parseWatchDuration(watchDuration)

    return {
        _id              = id,
        actions          = actions,
        linkAcc          = linkAcc,
        linkPost         = linkPost,
        commentContent   = commentContent,
        delay            = math.max(delay, 5),
        scrollCount      = math.max(1, scrollCount),
        watchDurationRaw = watchDuration ~= "" and watchDuration or "5-10",
        minWatch         = minWatch,
        maxWatch         = maxWatch
    }
end

----------------------------------------------------------------
-- 🔙 RETURN TO FEED
----------------------------------------------------------------
local function returnToFeed()
    toast("↩️ Trở về màn hình feed...")
    touchDown(2, 441.34, 146.03); usleep(66500);  touchUp(2, 441.34, 146.03);  usleep(1350000)
    touchDown(2, 429.03, 202.03); usleep(66600);  touchUp(2, 429.03, 202.03);  usleep(1760000)
    touchDown(2, 483.43, 214.26); usleep(68100);  touchUp(2, 483.43, 214.26);  usleep(1200000)
end

----------------------------------------------------------------
-- 🎞️ POST / DELETE / DOWNLOAD
----------------------------------------------------------------
function autoUploadVideo()
    toast("🚀 Upload Video – Restart TikTok...")
    delayKill()
    appKill("com.ss.iphone.ugc.Ame")
    sleep4()

    openURLSafe("snssdk1233://main")
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()

    local px, py = getBasePlus()
    tap(px, py)
    toast("📸 Nhấn WhitePlus")
    sleep4()

    toast("📂 Mở Library")
    touchDown(5, 91.35, 1270.06); usleep(250000); touchUp(5, 91.35, 1270.06); usleep(635000)
    tap(601, 1120); usleep(6000000)

    tap(351, 433)
    toast("🎞️ Chọn video đầu tiên")
    usleep(6000000)

    local nx, ny = findImgRetry("nextbutton.png", 0.4, 3)
    if nx then
        tap(nx, ny); usleep(1500000); tap(nx, ny)
    else
        tap(570,1283); usleep(1500000); tap(554,1286)
    end
    usleep(6000000)

    local postX, postY = findImgRetry("post.png", 0.4, 3)
    if postX then tap(postX, postY) else tap(554,1286) end
    toast("✅ Đăng video hoàn tất")
    sleep4()
end

----------------------------------------------------------------
-- 🧩 DELETEFLOW
----------------------------------------------------------------
local function handleDeleteConfirm()
    toast("🔍 Kiểm tra hộp thoại xác nhận...")
    local dx, dy = findImgRetry("delete1.png", 0.4, 2)
    if dx and dy then tap(dx, dy) toast("✅ Nhấn delete1.png") return end

    local ax, ay = findImgRetry("deleteall.png", 0.4, 2)
    if ax and ay then tap(ax, ay) toast("✅ Nhấn deleteall.png") return end

    local okx, oky = findImgRetry("ok.png", 0.4, 2)
    if okx and oky then tap(okx, oky) toast("⚠️ Nhấn OK") return end

    toast("🚫 Không phát hiện nút xác nhận – bỏ qua.")
end

function deleteVideo()
    toast("🧹 Bắt đầu DeleteFlow...")
    appKill("com.apple.shortcuts")
    sleep3()

    local shortcuts = {"DeleteVideo", "DeletePhoto", "AutoSaveVideo"}
    for _, name in ipairs(shortcuts) do
        local cmd = "shortcuts://run-shortcut?name=" .. name
        toast("🚀 Chạy Shortcut: " .. name)
        openURLSafe(cmd)
        sleep4()
        handleDeleteConfirm()
        sleep3()
    end

    toast("🏁 DeleteFlow hoàn tất.")
    sleep4()
end

----------------------------------------------------------------
-- ⬇️ DOWNLOAD
----------------------------------------------------------------
function downloadVideo()
    local encoded = fixedURL:gsub("([^%w])", function(c) return string.format("%%%02X", string.byte(c)) end)
    local cmd     = string.format('shortcuts://run-shortcut?name=%s&inputText=%s', shortcutSave, encoded)
    openURLSafe(cmd)
    sleep4()
end

----------------------------------------------------------------
-- 🆕 NUÔI KÊNH (GROWVIDEO)
----------------------------------------------------------------
local function swipeUpOnce()
    touchDown(1, 376.68, 835.32)
    usleep(100000)
    touchMove(1, 426.98, 266.19)
    usleep(150000)
    touchUp(1, 426.98, 266.19)
    usleep(400000)
end

function autoGrowVideo(opt)
    local loopCount = opt.scrollCount or 3
    local minW, maxW = opt.minWatch or 5, opt.maxWatch or 10
    local comments = opt.commentContent or {}

    toast("🪴 Bắt đầu nuôi kênh – " .. loopCount .. " vòng (xem " .. minW .. "-" .. maxW .. "s)")
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()

    local px, py = getBasePlus()

    for i = 1, loopCount do
        local swipeCount = math.random(3, 6)
        toast("🎬 Vòng " .. i .. "/" .. loopCount .. " – Lướt " .. swipeCount .. " video")

        for n = 1, swipeCount do
            swipeUpOnce()
            local t = math.random(minW, maxW)
            toast("⏸️ Xem video " .. n .. " trong " .. t .. " giây...")
            usleep(t * 1000000)
        end

        toast("❤️ Like video cuối (vòng " .. i .. ")")
        tap(px + 317, py - 660)
        sleep3()

        local cmt = (#comments > 0 and comments[i] or comments[1]) or "Nice video!"
        toast("💬 Comment: " .. cmt)
        tap(px + 320, py - 530)
        usleep(4000000)
        tap(px, py)
        usleep(2000000)
        inputText(cmt)
        usleep(2000000)
        tap(672, 752)
        sleep4()

        returnToFeed()
        sleep3()

        toast("🔄 Reset TikTok sau vòng " .. i)
        delayKill()
        appKill("com.ss.iphone.ugc.Ame")
        sleep4()
        appActivate("com.ss.iphone.ugc.Ame")
        sleep4()

        toast("✅ Hoàn tất vòng " .. i)
        usleep(1200000)
    end

    toast("🏁 Kết thúc nuôi kênh – đã thực hiện " .. loopCount .. " vòng")
end

----------------------------------------------------------------
-- 🧱 BLOCK HỖ TRỢ ACC-FLOW / POST-FLOW
----------------------------------------------------------------
local function collapseSuggested()
    toast("⬇️ Thu gọn Suggested…")
    sleep2()

    -- Toạ độ arrow (cho iPhone 6/7/8/DRX)
    local arrowX, arrowY = 536, 536
    tap(arrowX, arrowY)
    sleep2()

    toast("✅ Đã thu gọn Suggested")
end

-- mở random 1 trong 3 video đầu trong grid
local function openRandomVideoFromUser()
    toast("📜 Random 1 video trong 3 video đầu...")

    local slots = {
        {123, 1268},  -- video 1
        {370, 1268},  -- video 2
        {628, 1268}   -- video 3
    }

    local idx = math.random(1, #slots)
    local sx, sy = slots[idx][1], slots[idx][2]

    toast("📌 Tap video slot #" .. idx)
    tap(sx, sy)
    usleep(2500000)
end

local function hasAction(actions, name)
    for _, a in ipairs(actions or {}) do
        if a == name then return true end
    end
    return false
end

----------------------------------------------------------------
-- 🆕 ACC-FLOW CÁCH A
--  ACC1: follow → like → comment → share
--  ACC2: follow → like → comment → share
--  🔥 Không kill app sau mỗi tài khoản, chỉ jump liên tục
----------------------------------------------------------------
local function runAccFlow(opt, doFollow, doLike, doComment, doShare)
    if not opt.linkAcc or #opt.linkAcc == 0 then
        toast("⚠️ Không có linkAcc, bỏ qua ACC-FLOW")
        return
    end

    for idx, acc in ipairs(opt.linkAcc) do
        local username = acc:match("@([%w%._%-]+)")
        if username then
            toast(string.format("👤 ACC %d/%d: @%s", idx, #opt.linkAcc, username))

            -- KHÔNG KILL APP Ở ĐÂY
            openURLSafe("snssdk1233://user/@" .. username)
            appActivate("com.ss.iphone.ugc.Ame")
            sleep9()

            --------------------------------------------------
            -- FOLLOW
            --------------------------------------------------
            if doFollow then
                toast("➕ Follow tài khoản này...")
                local fx, fy = findImgRetry("follow_button.png", 0.4, 4)
                if fx then
                    tap(fx, fy)
                else
                    toast("⚠️ Không tìm thấy nút Follow")
                end
                sleep5()
            end

            --------------------------------------------------
            -- LIKE / COMMENT / SHARE TRÊN 1 VIDEO NGẪU NHIÊN
            --------------------------------------------------
            if doLike or doComment or doShare then
                collapseSuggested()
                openRandomVideoFromUser()
                local px, py = getBasePlus()

                if doLike then
                    toast("❤️ Like video của @" .. username)
                    tap(px + 317, py - 660)
                    sleep3()
                end

                if doComment then
                    local cmt = opt.commentContent[idx] or opt.commentContent[1] or "Nice!"
                    toast("💬 Comment: " .. cmt)

                    tap(px + 320, py - 530) -- mở ô comment
                    usleep(2500000)

                    tap(px, py)             -- chọn ô input
                    usleep(1500000)

                    inputText(cmt)
                    usleep(1500000)

                    tap(672, 752)           -- gửi
                    sleep3()

                    toast("⬆️ Đóng cửa sổ comment")
                    tap(366, 99)
                    sleep2()
                end

                if doShare then
                    toast("🔁 Share video của @" .. username)
                    tap(px + 320, py - 257)
                    sleep3()

                    local cx, cy = findImgRetry("copylink.png", 0.45, 4)
                    if cx then
                        toast("📎 Copy Link")
                        tap(cx, cy)
                    else
                        toast("⚠️ Không tìm thấy copylink.png")
                    end

                    sleep2()
                end
            end

            -- ❌ BỎ ĐOẠN KILL APP GIỮA CÁC ACC
            -- chỉ nhảy sang acc tiếp theo luôn
        end
    end
end

----------------------------------------------------------------
-- 🆕 POST-FLOW CÁCH A
--  POST1: like → comment → share
--  POST2: like → comment → share
----------------------------------------------------------------
local function runPostFlow(opt, doLike, doComment, doShare)
    if not opt.linkPost or #opt.linkPost == 0 then
        toast("⚠️ Không có linkPost, bỏ qua POST-FLOW")
        return
    end

    local comments = opt.commentContent or {}

    for idx, post in ipairs(opt.linkPost) do
        toast(string.format("🎯 POST %d/%d", idx, #opt.linkPost))
        openURLSafe(post)
        appActivate("com.ss.iphone.ugc.Ame")
        sleep7()

        local px, py = getBasePlus()

        --------------------------------------------------
        -- LIKE
        --------------------------------------------------
        if doLike then
            toast("❤️ Like bài đăng " .. idx)
            tap(px + 317, py - 660)
            sleep3()
        end

        --------------------------------------------------
        -- COMMENT
        --------------------------------------------------
        if doComment and #comments > 0 then
            local cmt = comments[idx] or comments[1] or "Nice!"
            toast("💬 Comment bài đăng " .. idx .. ": " .. cmt)

            tap(px + 320, py - 530) -- mở ô comment
            usleep(2500000)

            tap(px, py)             -- chọn ô nhập
            usleep(1500000)

            inputText(cmt)
            usleep(1500000)

            tap(672, 752)           -- gửi comment
            sleep3()

            toast("⬆️ Đóng cửa sổ comment")
            tap(366, 99)
            sleep2()
        end

        --------------------------------------------------
        -- SHARE
        --------------------------------------------------
        if doShare then
            toast("🔁 Share bài đăng " .. idx)
            tap(px + 320, py - 257)
            sleep3()

            local cx, cy = findImgRetry("copylink.png", 0.45, 4)
            if cx then
                toast("📎 Copy Link")
                tap(cx, cy)
            else
                toast("⚠️ Không tìm thấy copylink.png")
            end

            sleep2()
        end

        returnToFeed()
        sleep3()
    end
end

----------------------------------------------------------------
-- 🗺 ACTION MAP CHO CÁC HÀNH ĐỘNG PHỤ
----------------------------------------------------------------
local actionMap = {
    deletevideo   = deleteVideo,
    downloadvideo = downloadVideo,
    postvideo     = autoUploadVideo,
    uppost        = autoUploadVideo,
    growvideo     = autoGrowVideo
}

----------------------------------------------------------------
-- 🔁 MAIN LOOP – CÁCH A
-- 1. linkAcc  → ACC-FLOW
-- 2. Kill TikTok một lần → POST-FLOW
-- 3. Sau đó: delete / download / postvideo / uppost / growvideo
----------------------------------------------------------------
toast("🚀 TikTok AutoFlow v8.5p-DeleteFlowIntegrated_v1.8 (CÁCH A) Started...")

delayKill()
appKill("com.ss.iphone.ugc.Ame")
sleep5()

while true do
    delayKill()
    appKill("com.ss.iphone.ugc.Ame")
    sleep4()

    local resp = getAPIResponse()
    local opt  = extractOptions(resp)

    if not opt or not opt._id then
        toast("⚠️ API lỗi / không có _id hợp lệ")
        sleep4()
    else
        local actionId = opt._id
        sendLog(actionId, "Start drx tiktok", 1)
        toast("🆔 _id: " .. tostring(actionId))

        local acts = opt.actions or {}

        if #acts > 0 then
            -------------------------------------------------
            -- XÁC ĐỊNH HÀNH ĐỘNG CHÍNH
            -------------------------------------------------
            local doFollow  = hasAction(acts, "follow")
            local doLike    = hasAction(acts, "like")
            local doComment = hasAction(acts, "comment")
            local doShare   = hasAction(acts, "share")

            -------------------------------------------------
            -- 1️⃣ ACC-FLOW (NẾU CÓ linkAcc)
            -------------------------------------------------
            if opt.linkAcc and #opt.linkAcc > 0 and (doFollow or doLike or doComment or doShare) then
                toast("🧬 Bắt đầu ACC-FLOW (CÁCH A)...")
                pcall(function()
                    runAccFlow(opt, doFollow, doLike, doComment, doShare)
                end)
            else
                toast("ℹ️ Không có ACC-FLOW (thiếu linkAcc hoặc không tick follow/like/comment/share)")
            end

            -------------------------------------------------
            -- 2️⃣ POST-FLOW (NẾU CÓ linkPost)
            --    Kill app 1 lần TRƯỚC KHI SANG POST-FLOW
            -------------------------------------------------
            if opt.linkPost and #opt.linkPost > 0 and (doLike or doComment or doShare) then
                toast("🔄 Reset TikTok trước khi sang POST-FLOW...")
                delayKill()
                appKill("com.ss.iphone.ugc.Ame")
                sleep5()

                toast("🧬 Bắt đầu POST-FLOW (CÁCH A)...")
                pcall(function()
                    runPostFlow(opt, doLike, doComment, doShare)
                end)
            else
                toast("ℹ️ Không có POST-FLOW (thiếu linkPost hoặc không tick like/comment/share)")
            end

            -------------------------------------------------
            -- 3️⃣ CÁC ACTION PHỤ
            -------------------------------------------------
            for _, act in ipairs(acts) do
                if act == "deletevideo" or act == "downloadvideo"
                   or act == "postvideo" or act == "uppost"
                   or act == "growvideo" then

                    local fn = actionMap[act]
                    if fn then
                        toast("▶️ Thực hiện action phụ: " .. act)
                        pcall(function() fn(opt) end)
                        usleep((opt.delay or 5) * 1000000)
                    else
                        toast("⚙️ Không tìm thấy handler cho action: " .. act)
                    end
                end
            end

            delayLog()
            sendLog(actionId, "End drx tiktok", 2)
            toast("📨 Log End đã gửi xong.")
        else
            sendLog(actionId, "Fail drx tiktok (no actions)", 3)
            toast("⚠️ Không có actions được cấu hình từ API")
        end
    end

    sleep5()
end
