----------------------------------------------------------------
-- 🎬 TikTok AutoFlow v8.5p (FINAL CLEAN)
-- ACC-FLOW / POST-FLOW / UPLOADFLOW / GROWVIDEO
-- Start.lua đã cấp toàn bộ config → file này không cần sửa gì
----------------------------------------------------------------

local curl = require("cURL")

----------------------------------------------------------------
-- 🔧 LOAD CONFIG GLOBAL
----------------------------------------------------------------

local TIKTOK_BUNDLE = "com.ss.iphone.ugc.Ame"

local jwt        = _G.jwt
local deviceID   = _G.device_id
local deviceName = _G.device_name
local boxName    = _G.box_name
local host       = _G.host      -- Host từ config.json

if not jwt or not deviceID or not host then
    toast("❌ TikTokAuto.lua thiếu config – hãy chạy Start.lua")
    return
end

toast("🇺🇸 TikTok US ONLY – Bundle = " .. TIKTOK_BUNDLE)
toast("🌐 API HOST = [" .. tostring(host) .. "]")

----------------------------------------------------------------
-- 🌐 API GET ACTION
----------------------------------------------------------------
local apiGet = string.format(
    "%s/api/v1/tool/action/get?action_type=tiktok&jwt=%s&device_id=%s",
    host, jwt, deviceID
)

local imgPath = rootDir() .. "/core/img/"
local firstTikTokLoad = true

----------------------------------------------------------------
-- ⚙️ UTILITIES
----------------------------------------------------------------
local function sleep1() usleep(1000000) end
local function sleep2() usleep(2000000) end
local function sleep3() usleep(3000000) end
local function sleep4() usleep(4000000) end
local function sleep5() usleep(5000000) end
local function sleep6() usleep(6000000) end
local function sleep7() usleep(7000000) end
local function sleep8() usleep(8000000) end
local function sleep9() usleep(9000000) end
local function sleep20() usleep(20000000) end
local function delayKill() usleep(5000000) end
local function delayLog() usleep(5000000) end



-- 📌 CONVERT GOOGLE DRIVE / GENERIC DIRECT URL
local function normalizeURL(url)
    if not url or url == "" then return nil end

    -- Google Drive format:
    -- https://drive.google.com/file/d/ID/view
    local id = url:match("drive%.google%.com/file/d/(.-)/")
    if id then
        local direct = "https://drive.google.com/uc?export=download&id=" .. id
        toast("🔗 Google Drive → Direct link")
        return direct
    end

    -- Nếu là FMS hoặc HTTP/HTTPS bình thường → giữ nguyên
    return url
end


------------------------------------------------------
-- 📍 TAP FUNCTION (BẮT BUỘC CÓ)
------------------------------------------------------
local function tap(x, y, d)
    if not x or not y then return end
    touchDown(1, x, y)
    usleep(80000)          -- tốc độ chuẩn gõ TELEX iOS
    touchUp(1, x, y)
    usleep(d or 120000)    -- delay cực ngắn -> gõ không lỗi
end


------------------------------------------------------
-- 📍 MAP BÀN PHÍM (iPhone 6/7/8)
------------------------------------------------------
local key_SHIFT = {35,1190}
local key_123   = {25,1300}
local key_ABC   = {25,1300}

local keyboardMap = {
    ["q"]={36,960},["w"]={113,960},["e"]={188,960},["r"]={262,960},["t"]={337,960},
    ["y"]={413,960},["u"]={488,960},["i"]={561,960},["o"]={637,960},["p"]={713,960},

    ["a"]={75,1070},["s"]={148,1070},["d"]={222,1070},["f"]={299,1070},["g"]={378,1070},
    ["h"]={450,1070},["j"]={525,1070},["k"]={600,1070},["l"]={676,1070},

    ["z"]={150,1175},["x"]={223,1175},["c"]={300,1175},["v"]={375,1175},
    ["b"]={450,1175},["n"]={525,1175},["m"]={600,1175},

    [" "]={375,1286},
}

local numberMap = {
    ["1"]={37,962},["2"]={112,962},["3"]={186,962},
    ["4"]={264,962},["5"]={338,962},["6"]={441,962},
    ["7"]={488,962},["8"]={562,962},["9"]={638,962},
    ["0"]={713,962},
}

------------------------------------------------------
-- 🔥 TELEX MAP (CONVERT TV→TELEX)
------------------------------------------------------
local telexMap = {
    ["á"]="as", ["à"]="af", ["ả"]="ar", ["ã"]="ax", ["ạ"]="aj",
    ["ă"]="aw", ["ắ"]="aws", ["ằ"]="awf", ["ẳ"]="awr", ["ẵ"]="awx", ["ặ"]="awj",
    ["â"]="aa", ["ấ"]="aas", ["ầ"]="aaf", ["ẩ"]="aar", ["ẫ"]="aax", ["ậ"]="aaj",

    ["é"]="es", ["è"]="ef", ["ẻ"]="er", ["ẽ"]="ex", ["ẹ"]="ej",
    ["ê"]="ee", ["ế"]="ees", ["ề"]="eef", ["ể"]="eer", ["ễ"]="eex", ["ệ"]="eej",

    ["ó"]="os", ["ò"]="of", ["ỏ"]="or", ["õ"]="ox", ["ọ"]="oj",
    ["ô"]="oo", ["ố"]="oos", ["ồ"]="oof", ["ổ"]="oor", ["ỗ"]="oox", ["ộ"]="ooj",
    ["ơ"]="ow", ["ớ"]="ows", ["ờ"]="owf", ["ở"]="owr", ["ỡ"]="owx", ["ợ"]="owj",

    ["ú"]="us", ["ù"]="uf", ["ủ"]="ur", ["ũ"]="ux", ["ụ"]="uj",
    ["ư"]="uw", ["ứ"]="uws", ["ừ"]="uwf", ["ử"]="uwr", ["ữ"]="uwx", ["ự"]="uwj",

    ["í"]="is", ["ì"]="if", ["ỉ"]="ir", ["ĩ"]="ix", ["ị"]="ij",

    ["ý"]="ys", ["ỳ"]="yf", ["ỷ"]="yr", ["ỹ"]="yx", ["ỵ"]="yj",

    ["đ"]="dd", ["Đ"]="dd"
}

------------------------------------------------------
-- 🔥 Convert TV → TELEX
------------------------------------------------------
local function vnToTelex(str)
    local out = ""
    for c in str:gmatch("[%z\1-\127\192-\255][\128-\191]*") do
        local lower = c:lower()
        if telexMap[lower] then
            out = out .. telexMap[lower]
        else
            out = out .. c
        end
    end
    return out
end

------------------------------------------------------
-- 🔤 GÕ TỪNG KÝ TỰ (TELEX)
------------------------------------------------------
local function typeChar(c)
    if c == " " then
        tap(375,1286)
        return
    end

    local lower = c:lower()

    if keyboardMap[lower] then
        tap(keyboardMap[lower][1], keyboardMap[lower][2])
        return
    end

    if numberMap[c] then
        tap(key_123[1], key_123[2])
        usleep(150000)
        tap(numberMap[c][1], numberMap[c][2])
        tap(key_ABC[1], key_ABC[2])
        return
    end
end

------------------------------------------------------
-- 🧪 GÕ TELEX CHẬM
------------------------------------------------------
function typeSlowText(str)
    local telex = vnToTelex(str)
    for c in telex:gmatch(".") do
        typeChar(c)
        usleep(300000)
    end
end

local function findKeyboardOption(active, inactive)
    local x, y = findImgRetry(active, 0.70, 2)
    if x then return x, y end

    x, y = findImgRetry(inactive, 0.70, 2)
    if x then return x, y end

    return nil, nil
end


-- 🌐 ĐỔI BÀN PHÍM CHUẨN NHẤT – KHÔNG DÙNG ẢNH
local function switchKeyboardLayout(lang)
    toast("🌐 Đổi bàn phím → " .. lang)

    -- 1) mở popup
    touchDown(1, 140, 1285)   -- nút global
    usleep(1200000)
    touchUp(1, 140, 1285)
    usleep(500000)

    -- 2) toạ độ trong popup (iPhone 6/7/8 chuẩn DRX)
    local EN_X, EN_Y   = 240, 963   -- English (US)
    local VI_X, VI_Y   = 252, 1075   -- Tiếng Việt – Telex

    if lang == "en" then
        toast("Chọn English (US)")
        tap(EN_X, EN_Y, 500000)

    else
        toast("Chọn Tiếng Việt – Telex")
        tap(VI_X, VI_Y, 500000)
    end
end


-- 🧠 Kiểm tra chuỗi có phải tiếng Việt (có ký tự Unicode) không
local function isVietnamese(str)
    if not str or str == "" then return false end
    for c in str:gmatch("[%z\1-\127\192-\255][\128-\191]*") do
        -- ký tự ASCII (EN) chỉ dài 1 byte
        if #c > 1 then
            -- có ký tự Unicode → coi là tiếng Việt
            return true
        end
    end
    return false
end


------------------------------------------------------------
-- 📦 PARSE PRODUCT INFO (product_id | url | desc | name)
------------------------------------------------------------
local function parseProductLine(line)

    local url, desc, id, name = line:match("^(.-)%s*|%s*(.-)%s*|%s*(.-)%s*|%s*(.-)$")

    return {
        id   = id or "",
        url  = url or "",
        desc = desc or "",
        name = name or ""
    }
end

------------------------------------------------------------
-- COMMENT BẰNG GÕ TỪNG CHỮ
------------------------------------------------------------
------------------------------------------------------------
-- 🆕 COMMENT CHUẨN: AUTO VI / EN + HỖ TRỢ SỐ
------------------------------------------------------------
local function doCommentChar(px, py, cmt)
    toast("⌨️ Chuẩn bị gõ comment: " .. cmt)

    -- mở khung comment
    tap(px + 320, py - 530)
    usleep(1500000)

    -- chọn ô nhập
    tap(180, 1285)
    usleep(800000)

    -- kiểm tra loại comment
    local isVN  = isVietnamese(cmt)
    local hasNum = cmt:match("%d") ~= nil

    ------------------------------------------------------
    -- CHỌN BÀN PHÍM
    ------------------------------------------------------
    if hasNum then
        switchKeyboardLayout("en")   -- bắt buộc EN nếu có số
    elseif isVN then
        switchKeyboardLayout("vi")   -- tiếng Việt: dùng TELEX
    else
        switchKeyboardLayout("en")   -- tiếng Anh
    end

    ------------------------------------------------------
    -- GÕ COMMENT
    ------------------------------------------------------
    if isVN and not hasNum then
        -- tiếng Việt thuần → TELEX
        typeSlowText(cmt)
    else
        -- có số hoặc tiếng Anh → gõ từng ký tự
        for c in cmt:gmatch(".") do
            typeChar(c)
            usleep(250000)
        end
    end

    usleep(800000)

    -- Nút Send
    tap(681, 758)
    usleep(1200000)

    -- đóng comment
    tap(360, 290)
    usleep(600000)
end


local function findImgRetry(name, thr, retries)
    local threshold = thr or 0.4
    local fullPath  = imgPath .. name
    retries = retries or 3

    for i = 1, retries do
        toast("🔍 Tìm ảnh: " .. name .. " (lần " .. i .. ")")
        local r = findImage(fullPath, 1, threshold, nil, false, 2)
        if r and #r > 0 then
            local x, y = r[1][1], r[1][2]
            toast("✅ " .. name .. " tại [" .. math.floor(x) .. "," .. math.floor(y) .. "]")
            return x, y
        end
        usleep(800000)
    end

    toast("❌ Không thấy " .. name .. " sau " .. retries .. " lần")
    return nil, nil
end

local function getBasePlus()
    local x, y = findImgRetry("whiteplus.png", 0.4, 3)
    if x and y then return x, y end
    toast("⚠️ Fallback whiteplus → (381,1283)")
    return 381, 1283
end

local function openURLSafe(url)
    pcall(function()
        if type(openURL) == "function" then
            openURL(url)
        else
            require "objc"
            local NSURL         = objc.NSURL
            local UIApplication = objc.UIApplication
            UIApplication:sharedApplication():openURL_(NSURL:URLWithString_(url))
        end
    end)
    sleep4()
end

----------------------------------------------------------
-- 🆕 OPEN POST SAFE (DeepLink + Kill Safari)
----------------------------------------------------------
local function openPostDeep(post)
    -- Kill Safari để chặn chiếm link
    appKill("com.apple.mobilesafari")
    usleep(900000)

    -- Lấy video ID từ link
    local id = post:match("video/(%d+)")
    if id then
        local deep = "snssdk1233://aweme/detail/" .. id
        toast("🔗 DeepLink → " .. id)
        openURLSafe(deep)
    else
        -- fallback (link không đúng format)
        toast("🌐 Open via Web URL (fallback)")
        openURLSafe(post)
    end

    -- đảm bảo quay lại TikTok
    appActivate(TIKTOK_BUNDLE)
    sleep4()
end

----------------------------------------------------------------
-- 🌐 SERVER LOG
----------------------------------------------------------------
local function sendLog(actionId, logText, statusCode)
    if not actionId then
        toast("⚠️ Thiếu _id, bỏ qua log")
        return
    end

    local apiLog = string.format("%s/api/v1/tool/action/%s?jwt=%s", host, actionId, jwt)
    local body   = string.format('{"log":"%s","status":%d}', logText, statusCode)
    local resp   = ""

    local ok, err = pcall(function()
        local c = curl.easy{
            url           = apiLog,
            postfields    = body,
            customrequest = "PUT",
            httpheader    = {"Content-Type: application/json"},
            ssl_verifypeer = false,
            ssl_verifyhost = false,
            timeout        = 15,
            writefunction  = function(s) resp = resp .. s return #s end
        }
        c:perform()
        c:close()
    end)

    if not ok then
        toast("❌ Lỗi gửi log: " .. tostring(err))
    else
        local code = resp:match('"code"%s*:%s*(%d+)') or "???"
        toast(string.format("📤 PUT Log [%d] – %s (code:%s)", statusCode, logText, code))
    end
end

----------------------------------------------------------------
-- 🛰️ API GET
----------------------------------------------------------------
local function getAPIResponse()
    local response = ""
    local c = curl.easy{
        url            = apiGet,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction  = function(s) response = response .. s return #s end
    }
    pcall(function() c:perform() end)
    c:close()
    return response
end

----------------------------------------------------------------
-- 🧠 PARSE RESPONSE
----------------------------------------------------------------
local ORDER = {
    "follow","like","share","comment",
    "deletevideo","downloadvideo","postvideo","uppost","growvideo"
}

local function sortActions(actions)
    table.sort(actions, function(a, b)
        local ia, ib = 999, 999
        for i, v in ipairs(ORDER) do
            if v == a then ia = i end
            if v == b then ib = i end
        end
        return ia < ib
    end)
    return actions
end

local function parseWatchDuration(raw)
    local minW, maxW = 5, 10
    if not raw or raw == "" then return minW, maxW end

    if raw:find("%-") then
        local a, b = raw:match("(%d+)%-(%d+)")
        if a and b then
            minW, maxW = tonumber(a) or 5, tonumber(b) or 10
            if minW > maxW then minW, maxW = maxW, minW end
        end
    else
        local v = tonumber(raw)
        if v then minW, maxW = v, v end
    end

    minW = math.max(1, math.floor(minW))
    maxW = math.max(minW, math.floor(maxW))
    return minW, maxW
end

local function extractOptions(resp)
    if not resp or resp == "" then return nil end

    local id = resp:match('"_id"%s*:%s*"(.-)"')
    if not id then
        toast("⚠️ Không tìm thấy _id trong phản hồi")
        return nil
    end

    local actions, linkAcc, linkPost, commentContent = {}, {}, {}, {}

    for a in resp:gmatch('"actions"%s*:%s*%[(.-)%]') do
        for v in a:gmatch('"(.-)"') do
            table.insert(actions, v:lower())
        end
    end
    actions = sortActions(actions)

    for b in resp:gmatch('"linkAcc"%s*:%s*%[(.-)%]') do
        for v in b:gmatch('"(.-)"') do
            table.insert(linkAcc, v)
        end
    end

    for c in resp:gmatch('"linkPost"%s*:%s*%[(.-)%]') do
        for v in c:gmatch('"(.-)"') do
            table.insert(linkPost, v)
        end
    end

    -- xoá phần tử linkPost rỗng để tránh lỗi
    for i = #linkPost, 1, -1 do
        if not linkPost[i] or linkPost[i] == "" or linkPost[i] == " " then
            table.remove(linkPost, i)
        end
    end

    for d in resp:gmatch('"commentContent"%s*:%s*%[(.-)%]') do
        for v in d:gmatch('"(.-)"') do
            table.insert(commentContent, v)
        end
    end

    ------------------------------------------------------
    -- 🆕 PRODUCT INFO
    ------------------------------------------------------
    local productInfo = {}
    for d in resp:gmatch('"productInfo"%s*:%s*%[(.-)%]') do
        for v in d:gmatch('"(.-)"') do
            table.insert(productInfo, v)
        end
    end


    local delay          = tonumber(resp:match('"delaySec"%s*:%s*(%d+)')) or 5
    local scrollCountRaw = resp:match('"scrollCount"%s*:%s*"(.-)"') or resp:match('"scrollCount"%s*:%s*(%d+)')
    local scrollCount    = tonumber(scrollCountRaw) or 3
    local watchDuration  = resp:match('"watchDuration"%s*:%s*"(.-)"') or ""
    local minWatch, maxWatch = parseWatchDuration(watchDuration)

        return {
        _id              = id,
        actions          = actions,
        linkAcc          = linkAcc,
        linkPost         = linkPost,
        commentContent   = commentContent,
        productInfo      = productInfo,   -- 🆕 THÊM DÒNG NÀY
        delay            = math.max(delay, 5),
        scrollCount      = math.max(1, scrollCount),
        watchDurationRaw = watchDuration ~= "" and watchDuration or "5-10",
        minWatch         = minWatch,
        maxWatch         = maxWatch
    }

end

----------------------------------------------------------------
-- 🔙 RETURN TO FEED
----------------------------------------------------------------
local function returnToFeed()
    toast("↩️ Trở về màn hình feed...")
    touchDown(2, 441.34, 146.03); usleep(66500);  touchUp(2, 441.34, 146.03);  usleep(1350000)
    touchDown(2, 429.03, 202.03); usleep(66600);  touchUp(2, 429.03, 202.03);  usleep(1760000)
    touchDown(2, 483.43, 214.26); usleep(68100);  touchUp(2, 483.43, 214.26);  usleep(1200000)
end

----------------------------------------------------------------
-- 🎞️ POST / DELETE / DOWNLOAD
----------------------------------------------------------------
function autoUploadVideo(opt, product)
    toast("🚀 Bắt đầu Upload Video...")

    ------------------------------------------
    -- 0. Reset + mở TikTok
    ------------------------------------------
    appKill(TIKTOK_BUNDLE)
    sleep3()
    appActivate(TIKTOK_BUNDLE)
    sleep5()

    ------------------------------------------
    -- 1. Tìm và nhấn nút POST (whiteplus.png)
    ------------------------------------------
    toast("🔍 Tìm nút POST (whiteplus)...")

    local px, py = findImgRetry("whiteplus.png", 0.45, 3)
    if px and py then
        toast("✅ Nhấn vào whiteplus (POST)")
        tap(px, py, 800000)
    else
        toast("⚠️ Không tìm thấy whiteplus → dùng fallback (376,1287)")
        tap(376, 1287, 800000)
    end

    sleep5()

    ------------------------------------------
    -- 2. Chuyển sang tab CREATE
    ------------------------------------------
    tap(525, 1269, 1000000)
    sleep3()

    ------------------------------------------
    -- 3. Nhấn NEW VIDEO
    ------------------------------------------
    tap(280, 345, 1000000)
    sleep3()

    ------------------------------------------
    -- 4. Nhấn tab VIDEOS
    ------------------------------------------
    tap(242, 190, 1000000)
    sleep3()

    ------------------------------------------
    -- 5. Chọn video đầu tiên
    ------------------------------------------
    tap(113, 415, 1000000)
    sleep4()

    ------------------------------------------
    -- 6. NEXT (dưới cùng bên phải)
    ------------------------------------------
    local nx, ny = findImgRetry("next_button.png", 0.72, 5)
    if nx then tap(nx, ny, 800000)
    else toast("❌ Không thấy nút NEXT") end
    sleep5()

    ------------------------------------------
    -- 7. NEXT góc phải trên
    ------------------------------------------
    local ax2, ay2 = findImgRetry("arrow_next.png", 0.72, 5)
    if ax2 then tap(ax2, ay2, 800000)
    else toast("❌ Không thấy mũi tên NEXT") end
    sleep6()

   ----------------------------------------------------------
-- 8. Add description (AUTO DETECT + SWITCH KEYBOARD + SUPPORT NUMBER)
----------------------------------------------------------
tap(67, 176, 1000000)   -- tap vào ô Description
sleep2()

local desc = product.desc or ""

if desc ~= "" then
    local isVN  = isVietnamese(desc)
    local hasNum = desc:match("%d") ~= nil

    ----------------------------------------------------------
    -- ⚙️ LOGIC CHỌN BÀN PHÍM
    -- VIỆT + KHÔNG SỐ → dùng TELEX
    -- CÓ SỐ → ÉP DÙNG ENGLISH (ổn định nhất khi gõ số)
    ----------------------------------------------------------
    if hasNum then
        switchKeyboardLayout("en")
    elseif isVN then
        switchKeyboardLayout("vi")
    else
        switchKeyboardLayout("en")
    end

    toast("⌨️ Gõ Description...")

    ----------------------------------------------------------
    -- GÕ MÔ TẢ
    ----------------------------------------------------------
    if isVN and not hasNum then
        -- GÕ TELEX (không có số)
        typeSlowText(desc)
    else
        -- GÕ TỪNG KÝ TỰ (có số hoặc tiếng Anh)
        for c in desc:gmatch(".") do
            typeChar(c)
            usleep(300000)
        end
    end

    usleep(600000)
    tap(369, 700, 500000)   -- đóng bàn phím
    sleep2()
else
    toast("⚠️ Description rỗng → bỏ qua")
end



    ------------------------------------------
    -- 9. Add Link
    ------------------------------------------
    local lx, ly = findImgRetry("add_link.png", 0.70, 5)
    if lx then tap(lx, ly, 700000)
    else toast("❌ Không thấy Add link") end
    sleep2()

    ------------------------------------------
    -- 10. Chọn Product
    ------------------------------------------
    local px2, py2 = findImgRetry("icon_product.png", 0.75, 5)
    if px2 then tap(px2, py2, 800000)
    else toast("❌ Không thấy icon Product") end
    sleep4()

    ------------------------------------------
    -- 11. Tap vào 'Add more products'
    ------------------------------------------
    toast("📦 Mở Add more products...")
    tap(370, 1299, 700000)
    sleep4()

    ------------------------------------------
    -- 12. Chọn Product Marketplace
    ------------------------------------------
    toast("🏪 Mở Product Marketplace...")

    local pmx, pmy = findImgRetry("product_marketplace.png", 0.75, 5)
    if pmx then 
        tap(pmx, pmy, 700000)
    else
        toast("⚠️ Không thấy product_marketplace.png")
    end
    sleep4()


    ------------------------------------------
    -- 13. Tap vào ô Search
    ------------------------------------------
    toast("🔍 Tap ô Search Product...")
    tap(107, 163, 700000)
    sleep4()


    ------------------------------------------
    -- 14. Nhập Product ID + Search
    ------------------------------------------
    toast("⌨️ Nhập Product ID: " .. product.id)

    typeSlowText(product.id)
    usleep(1000000)

    tap(719, 1317)  -- nút search bàn phím
    sleep4()


    ------------------------------------------
    -- 15. Nhấn Add sản phẩm
    ------------------------------------------
    toast("🛍️ Đang tìm nút Add...")

    local adx, ady = findImgRetry("add_button.png", 0.70, 5)
    if adx then 
        tap(adx, ady, 700000)
    else
        toast("⚠️ Không thấy add_product_button.png → fallback")
        tap(360, 640)  -- fallback vào giữa màn
    end

    sleep6()

    ------------------------------------------
    -- 16. XÓA PRODUCT NAME + GÕ TÊN MỚI
    ------------------------------------------
    toast("✏️ Đang sửa Product Name...")

    -- Xóa bằng giữ backspace
    touchDown(1, 720, 1177)
    usleep(6000000)
    touchUp(1, 720, 1177)
    sleep1()

    -- Gõ tên mới
----------------------------------------------------------
-- GÕ PRODUCT NAME (AUTO DETECT + SUPPORT NUMBER)
----------------------------------------------------------
local name = product.name or ""
local isVN2 = isVietnamese(name)
local hasNum2 = name:match("%d") ~= nil

-- CHỌN BÀN PHÍM
if hasNum2 then
    switchKeyboardLayout("en")
elseif isVN2 then
    switchKeyboardLayout("vi")
else
    switchKeyboardLayout("en")
end

-- GÕ TÊN SẢN PHẨM
if isVN2 and not hasNum2 then
    typeSlowText(name)
else
    for c in name:gmatch(".") do
        typeChar(c)
        usleep(300000)
    end
end
    sleep1()
    tap(720, 1300, 500000)
    sleep1()

    ------------------------------------------
    -- 17. NHẤN ADD
    ------------------------------------------
    local ax_add, ay_add = findImgRetry("add_button.png", 0.55, 5)
    if ax_add then
        tap(ax_add, ay_add, 800000)
    else
        toast("⚠️ Không thấy addbutton.png → fallback")
        tap(374, 1297, 900000)
    end

    sleep4()
    ------------------------------------------
    -- 18. NHẤN POST
    ------------------------------------------
    toast("📤 Đang tìm nút POST...")

    -- Tìm nút POST bằng ảnh
    local ax_post, ay_post = findImgRetry("post_button.png", 0.70, 3)

    if ax_post then
        toast("✅ Tìm thấy nút POST → Tap")
        tap(ax_post, ay_post, 900000)
    else
        toast("⚠️ Không thấy post_button.png → dùng fallback tọa độ")
        tap(374, 1297, 900000)  
    end

    sleep5()
end

----------------------------------------------------------------
-- 🧩 DELETEFLOW
----------------------------------------------------------------
local function handleDeleteConfirm()
    toast("🔍 Kiểm tra popup xoá iOS...")

    -- iPhone 6S popup delete:
    local deleteX, deleteY = 370, 980
    local alwaysX, alwaysY = 370, 1060

    -- Tap Delete
    toast("🗑️ Tap Delete (popup iOS)")
    tap(deleteX, deleteY)
    usleep(800000)

    -- Tap Delete Always (nếu có)
    toast("🗑️ Tap Delete Always (popup iOS)")
    tap(alwaysX, alwaysY)
    usleep(800000)
end

function deleteVideo()
    toast("🗑️ Xoá video mới nhất…")

    appKill("com.apple.shortcuts")
    usleep(1500000)

    -- Shortcut chỉ xoá video, không xoá ảnh
    local cmd = "shortcuts://run-shortcut?name=DeleteVideo"
    openURLSafe(cmd)

    sleep4()
    toast("✅ Đã xoá video mới nhất.")
end



-- ⬇️ DOWNLOAD VIDEO (FOR AutoSaveVideo2 – NO CLIPBOARD)
function downloadVideo(url)
    if not url or url == "" then
        toast("⚠️ URL video rỗng – bỏ qua download")
        return
    end

    toast("🔗 Chuẩn bị tải video...")

    -- Không dùng clipboard, chỉ encode URL
    local encoded = url:gsub("([^%w])", function(c)
        return string.format("%%%02X", string.byte(c))
    end)

    -----------------------------------------------------
    --  Gửi URL trực tiếp vào Shortcut qua param input=
    -----------------------------------------------------
    local cmd = "shortcuts://run-shortcut?name=AutoSaveVideo2&input=" .. encoded

    toast("🚀 Mở Shortcut AutoSaveVideo2...")
    openURL(cmd)

     -----------------------------------------------------
    -- ⏳ CHỜ 60 GIÂY CHO TẢI VIDEO
    -----------------------------------------------------
    toast("⏳ Đang chờ Shortcut tải video (60s)...")
    usleep(60000000)  -- 60 giây

    toast("✅ Đã gửi URL sang Shortcut")
end



----------------------------------------------------------------
-- 🆕 NUÔI KÊNH (GROWVIDEO)
----------------------------------------------------------------
local function swipeUpOnce()
    touchDown(1, 376.68, 751.32)
    usleep(100000)
    touchMove(1, 426.98, 266.19)
    usleep(150000)
    touchUp(1, 426.98, 266.19)
    usleep(400000)
end

function autoGrowVideo(opt)

    ------------------------------------------------------
    -- 🔥 KILL APP TRƯỚC KHI BẮT ĐẦU NUÔI KÊNH (THÊM MỚI)
    ------------------------------------------------------
    toast("♻️ Reset TikTok trước khi NUÔI KÊNH...")
    delayKill()
    appKill(TIKTOK_BUNDLE)
    sleep4()
    appActivate(TIKTOK_BUNDLE)
    sleep4()

    local loopCount = opt.scrollCount or 3
    local minW, maxW = opt.minWatch or 5, opt.maxWatch or 10
    local comments = opt.commentContent or {}

    toast("🪴 Bắt đầu nuôi kênh – " .. loopCount .. " vòng (xem " .. minW .. "-" .. maxW .. "s)")
    appActivate(TIKTOK_BUNDLE)
    sleep4()

    local px, py = getBasePlus()

    for i = 1, loopCount do
        local swipeCount = math.random(3, 6)
        toast("🎬 Vòng " .. i .. "/" .. loopCount .. " – Lướt " .. swipeCount .. " video")

        for n = 1, swipeCount do
            swipeUpOnce()
            local t = math.random(minW, maxW)
            toast("⏸️ Xem video " .. n .. " trong " .. t .. " giây...")
            usleep(t * 1000000)
        end

        ------------------------------------------------------
        -- LIKE video cuối
        ------------------------------------------------------
        toast("❤️ Like video cuối (vòng " .. i .. ")")
        tap(px + 317, py - 660)
        sleep3()

        ------------------------------------------------------
        -- COMMENT video cuối (giống ACC-FLOW)
        ------------------------------------------------------
        local cmt = (#comments > 0 and comments[i] or comments[1]) or "Nice!"
        toast("💬 Comment: " .. cmt)
        doCommentChar(px, py, cmt)



        toast("🔄 Reset TikTok sau vòng " .. i)
        delayKill()
        appKill(TIKTOK_BUNDLE)
        sleep4()
        appActivate(TIKTOK_BUNDLE)
        sleep4()

        toast("✅ Hoàn tất vòng " .. i)
        usleep(1200000)
    end

    toast("🏁 Kết thúc nuôi kênh – đã thực hiện " .. loopCount .. " vòng")
end

----------------------------------------------------------------
-- 🧱 BLOCK HỖ TRỢ ACC-FLOW / POST-FLOW
----------------------------------------------------------------
local function collapseSuggested()
    toast("⬇️ Thu gọn Suggested…")
    sleep2()

    -- Toạ độ arrow (cho iPhone 6/7/8/DRX)
    local arrowX, arrowY = 536, 536
    tap(arrowX, arrowY)

    toast("✅ Đã thu gọn Suggested")
end

-- mở random 1 trong 3 video đầu trong grid
local function openRandomVideoFromUser()
    toast("📜 Random 1 video trong 3 video đầu...")

    local slots = {
        {123, 1268},  -- video 1
        {370, 1268},  -- video 2
        {628, 1268}   -- video 3
    }

    local idx = math.random(1, #slots)
    local sx, sy = slots[idx][1], slots[idx][2]

    toast("📌 Tap video slot #" .. idx)
    tap(sx, sy)
    usleep(2500000)
end

local function hasAction(actions, name)
    for _, a in ipairs(actions or {}) do
        if a == name then return true end
    end
    return false
end

----------------------------------------------------------------
-- 🆕 ACC-FLOW CÁCH A
--  ACC1: follow → like → comment → share
--  ACC2: follow → like → comment → share
--  🔥 Không kill app sau mỗi tài khoản, chỉ jump liên tục
----------------------------------------------------------------
local function runAccFlow(opt, doFollow, doLike, doComment, doShare, isNewAction)
    if not opt.linkAcc or #opt.linkAcc == 0 then return end

    for idx, acc in ipairs(opt.linkAcc) do
        local username = acc:match("@([%w%._%-]+)")
        if username then

            toast("👤 Mở tài khoản " .. username)

            local accURL = "snssdk1233://user/@" .. username

            openURLSafe(accURL)
            appActivate(TIKTOK_BUNDLE)

            ------------------------------------------------------
            -- 1) LẦN ĐẦU TIKTOK MỞ LÊN SAU KHI KILL → 9 GIÂY
            ------------------------------------------------------
            if idx == 1 then
                if isNewAction then
                    toast("⏳ ACTION mới → TikTok load lần đầu → đợi 20s")
                    sleep20()
                else
                    usleep(2000000)
                end
            end

            ------------------------------------------------------
            -- FOLLOW
            ------------------------------------------------------
            if doFollow then
                local fx, fy = findImgRetry("follow_button.png", 0.4, 4)
                if fx then tap(fx, fy) end
                usleep(1000000)  -- delay 1 giây
            end

            ------------------------------------------------------
            -- SUGGESTED
            ------------------------------------------------------
            collapseSuggested()

            ------------------------------------------------------
            -- LIKE / COMMENT / SHARE
            ------------------------------------------------------
            if doLike or doComment or doShare then
                openRandomVideoFromUser()
                local px, py = getBasePlus()

                if doLike then
                    tap(px + 317, py - 660)
                    sleep3()
                end

                if doComment then
                local cmt = opt.commentContent[idx] or opt.commentContent[1] or "Nice!"
                doCommentChar(px, py, cmt)
            end


                if doShare then
                    tap(px + 320, py - 257)
                    sleep3()
                    local cx, cy = findImgRetry("copylink.png", 0.45, 4)
                    if cx then tap(cx, cy) end
                    sleep2()
                end
            end

        end
    end
end


----------------------------------------------------------------
-- 🆕 POST-FLOW CÁCH A
--  POST1: like → comment → share
--  POST2: like → comment → share
----------------------------------------------------------------
local function runPostFlow(opt, doLike, doComment, doShare, isNewAction)
    if not opt.linkPost or #opt.linkPost == 0 then
        toast("⚠️ Không có linkPost, bỏ qua POST-FLOW")
        return
    end

    local comments = opt.commentContent or {}

    for idx, post in ipairs(opt.linkPost) do
    toast(string.format("🎯 POST %d/%d", idx, #opt.linkPost))
    openPostDeep(post)

    if idx == 1 then
        if isNewAction then
            toast("⏳ ACTION mới → POST đầu tiên → đợi 7s")
            sleep7()
        else
            toast("⚡ POST load nhanh → 2s")
            usleep(2000000)
        end
    else
        usleep(2000000)
    end



        local px, py = getBasePlus()

        --------------------------------------------------
        -- LIKE
        --------------------------------------------------
        if doLike then
            toast("❤️ Like bài đăng " .. idx)
            tap(px + 317, py - 660)
            sleep3()
        end

        --------------------------------------------------
        -- COMMENT
        --------------------------------------------------
        if doComment and #comments > 0 then
            local cmt = comments[idx] or comments[1] or "Nice!"
            toast("💬 Comment bài đăng " .. idx .. ": " .. cmt)
            doCommentChar(px, py, cmt)
        end

        --------------------------------------------------
        -- SHARE
        --------------------------------------------------
        if doShare then
            toast("🔁 Share bài đăng " .. idx)
            tap(px + 320, py - 257)
            sleep3()

            local cx, cy = findImgRetry("copylink.png", 0.45, 4)
            if cx then
                toast("📎 Copy Link")
                tap(cx, cy)
            else
                toast("⚠️ Không tìm thấy copylink.png")
            end

            sleep2()
        end

        returnToFeed()
        sleep3()
    end
end

----------------------------------------------------------------
-- 🆕 UPLOAD FLOW MỚI: delete → kill → download → upload → delete → kill → next
----------------------------------------------------------------
local function uploadFlow(opt)
    if not opt.productInfo or #opt.productInfo == 0 then
        toast("⚠️ Không có productInfo → dừng uploadFlow")
        return
    end

    for i, line in ipairs(opt.productInfo) do
        local product = parseProductLine(line)

        toast(string.format("📦 [Video %d/%d] BẮT ĐẦU FLOW MỚI", i, #opt.productInfo))

        ------------------------------------------------
        -- 1️⃣ DELETE VIDEO CŨ TRƯỚC KHI LÀM GÌ
        ------------------------------------------------
        toast("🗑️ Xoá video cũ trước khi tải mới...")
        deleteVideo()
        sleep3()

        ------------------------------------------------
        -- 2️⃣ KILL SHORTCUTS TRƯỚC MỖI LẦN DOWNLOAD
        ------------------------------------------------
        toast("♻️ Kill Shortcuts trước khi tải video...")
        appKill("com.apple.shortcuts")
        sleep2()

        ------------------------------------------------
        -- 3️⃣ DOWNLOAD VIDEO
        ------------------------------------------------
        if product.url and product.url ~= "" then
            toast("⬇️ Download video " .. i)
            downloadVideo(product.url)
            sleep4()
        else
            toast("⚠️ URL video rỗng → bỏ qua")
        end

        ------------------------------------------------
        -- 4️⃣ UPLOAD VIDEO LÊN TIKTOK
        ------------------------------------------------
        toast("📤 Upload video lên TikTok...")
        autoUploadVideo(opt, product)
        sleep4()

        ------------------------------------------------
        -- 5️⃣ XÓA VIDEO ĐÃ TẢI VỀ SAU KHI UPLOAD
        ------------------------------------------------
        toast("🗑️ Xoá video vừa tải để tránh trùng lặp...")
        deleteVideo()
        sleep4()

        ------------------------------------------------
        -- 6️⃣ KILL TIKTOK SAU MỖI VIDEO
        ------------------------------------------------
        toast("♻️ Reset TikTok sau khi hoàn tất video #" .. i)
        appKill(TIKTOK_BUNDLE)
        sleep4()

        toast("✅ XONG VIDEO #" .. i)
        sleep2()
    end

    toast("🎉 Đã hoàn thành toàn bộ UPLOAD FLOW theo thứ tự mới!")
end



local actionMap = {
    uploadflow = uploadFlow,   
    growvideo     = autoGrowVideo
}


----------------------------------------------------------------
-- 🔁 MAIN LOOP – CÁCH A
-- 1. linkAcc  → ACC-FLOW
-- 2. Kill TikTok một lần → POST-FLOW
-- 3. Sau đó: delete / download / postvideo / uppost / growvideo
----------------------------------------------------------------
toast("🚀 TikTok AutoFlow Started...")

delayKill()
appKill(TIKTOK_BUNDLE)
sleep5()

while true do
    delayKill()
    appKill(TIKTOK_BUNDLE)
    sleep4()

    local resp = getAPIResponse()
    local opt  = extractOptions(resp)

    if not opt or not opt._id then
        toast("⚠️ API lỗi / không có _id hợp lệ")
        sleep4()
    else
        local actionId = opt._id
        local isNewAction = false
        if lastActionId ~= actionId then
            lastActionId = actionId
            isNewAction = true
        end

        sendLog(actionId, "Start drx tiktok", 1)
        toast("🆔 _id: " .. tostring(actionId))

        local acts = opt.actions or {}

        if #acts > 0 then
            -------------------------------------------------
            -- XÁC ĐỊNH HÀNH ĐỘNG CHÍNH
            -------------------------------------------------
            local doFollow  = hasAction(acts, "follow")
            local doLike    = hasAction(acts, "like")
            local doComment = hasAction(acts, "comment")
            local doShare   = hasAction(acts, "share")

            -------------------------------------------------
            -- 1️⃣ ACC-FLOW (NẾU CÓ linkAcc)
            -------------------------------------------------
            if opt.linkAcc and #opt.linkAcc > 0 and (doFollow or doLike or doComment or doShare) then
                toast("🧬 Bắt đầu ACC-FLOW (CÁCH A)...")
                pcall(function()
                    runAccFlow(opt, doFollow, doLike, doComment, doShare, isNewAction)
                end)
            else
                toast("ℹ️ Không có ACC-FLOW (thiếu linkAcc hoặc không tick follow/like/comment/share)")
            end

            -------------------------------------------------
            --2️⃣POST-FLOW (NẾU CÓ linkPost)
            --Kill app → mở TikTok → CHỜ 9 GIÂY → xử lý bài đăng
            -------------------------------------------------
            if opt.linkPost and #opt.linkPost > 0 and (doLike or doComment or doShare) then
                toast("🔄 Reset TikTok trước khi sang POST-FLOW...")
                delayKill()
                appKill(TIKTOK_BUNDLE)
                sleep4()

                toast("📲 Mở TikTok lại trước khi xử lý bài đăng")
                appActivate(TIKTOK_BUNDLE)

                toast("⏳ Chờ TikTok load (7 giây)...")
                sleep7()   -- 🔥 BẮT BUỘC PHẢI ĐỢI NHƯ LẦN ĐẦU

                toast("🧬 Bắt đầu POST-FLOW...")
                pcall(function()
                    runPostFlow(opt, doLike, doComment, doShare, isNewAction)
                end)
            else
                toast("ℹ️ Không có POST-FLOW")
            end


            -------------------------------------------------
            -- 3️⃣ CÁC ACTION PHỤ
            -------------------------------------------------
            for _, act in ipairs(acts) do
    if act == "uploadflow" or act == "growvideo" then
        local fn = actionMap[act]
        if fn then
            toast("▶️ Thực hiện action phụ: " .. act)
            pcall(function() fn(opt) end)
            usleep((opt.delay or 5) * 1000000)
        end
    end
end

            delayLog()
            sendLog(actionId, "End drx tiktok", 2)
            toast("📨 Log End đã gửi xong.")
        else
            sendLog(actionId, "Fail drx tiktok (no actions)", 3)
            toast("⚠️ Không có actions được cấu hình từ API")
        end
    end

    sleep5()
end
