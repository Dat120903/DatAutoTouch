----------------------------------------------------------------
-- 🔄 update.lua – AUTO UPDATE + AUTO CLEAN (FINAL)
-- • Tải update.zip từ GitHub
-- • Giải nén
-- • Ghi đè file cần update
-- • XOÁ update.zip sau khi xong
----------------------------------------------------------------

local url = "https://raw.githubusercontent.com/Dat120903/DatAutoTouch/main/update/update.zip"

local baseDir   = rootDir()
local coreDir   = baseDir .. "/core"
local zipPath   = baseDir .. "/update.zip"
local extractTo = baseDir .. "/__update_tmp__"

----------------------------------------------------------------
-- 🧾 Kiểm tra file tồn tại
----------------------------------------------------------------
local function fileExists(path)
    local f = io.open(path, "r")
    if f then f:close() return true end
    return false
end

----------------------------------------------------------------
-- 🧹 Cleanup an toàn
----------------------------------------------------------------
local function safeRemove(path)
    execute(string.format('rm -rf "%s"', path))
end

toast("🔄 Bắt đầu UPDATE...")

----------------------------------------------------------------
-- 1️⃣ XÓA RÁC CŨ (NẾU CÓ)
----------------------------------------------------------------
safeRemove(zipPath)
safeRemove(extractTo)

----------------------------------------------------------------
-- 2️⃣ TẢI update.zip
----------------------------------------------------------------
toast("⬇️ Đang tải update.zip...")
execute(string.format('curl -k -L "%s" -o "%s"', url, zipPath))

if not fileExists(zipPath) then
    toast("❌ Tải update.zip thất bại!")
    return
end

----------------------------------------------------------------
-- 3️⃣ GIẢI NÉN RA THƯ MỤC TẠM
----------------------------------------------------------------
toast("📦 Giải nén update...")
execute(string.format('mkdir -p "%s"', extractTo))
execute(string.format('unzip -o "%s" -d "%s"', zipPath, extractTo))

----------------------------------------------------------------
-- 4️⃣ DANH SÁCH FILE ĐƯỢC PHÉP UPDATE
----------------------------------------------------------------
local updateList = {
    "TikTokAuto.lua",
    "FacebookAuto.lua",
    "Creater.lua"
}

for _, fileName in ipairs(updateList) do
    local newFile = extractTo .. "/" .. fileName
    local oldFile = coreDir .. "/" .. fileName

    if fileExists(newFile) then
        execute(string.format('cp "%s" "%s"', newFile, oldFile))
        toast("✅ Updated: " .. fileName)
    else
        toast("⚠️ Không có trong update.zip: " .. fileName)
    end
end

----------------------------------------------------------------
-- 5️⃣ XOÁ FILE TẠM + ZIP
----------------------------------------------------------------
toast("🧹 Dọn dẹp file tạm...")
safeRemove(zipPath)
safeRemove(extractTo)

----------------------------------------------------------------
-- 6️⃣ DONE
----------------------------------------------------------------
toast("🎉 UPDATE HOÀN TẤT!")
toast("🔁 Vui lòng chạy lại Start.lua để dùng bản mới")
