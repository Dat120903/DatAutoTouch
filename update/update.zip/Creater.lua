----------------------------------------------------------------
-- 🌐 IBestCloud Device Creater (FINAL – Safe Mode)
-- By Mr.L – Optimized for Start.lua AutoConfig System
----------------------------------------------------------------

local curl = require("cURL")

----------------------------------------------------------------
-- 🔧 LOAD GLOBAL CONFIG (Start.lua đã gán)
----------------------------------------------------------------
local jwt        = _G.jwt
local deviceID   = _G.device_id
local deviceName = _G.device_name
local boxName    = _G.box_name
local host       = _G.host

----------------------------------------------------------------
-- 📌 VALIDATION
----------------------------------------------------------------
if not jwt or not deviceID or not deviceName or not boxName or not host then
    toast("❌ Creater.lua: Thiếu config từ Start.lua")
    return
end

----------------------------------------------------------------
-- 🌍 API URL
----------------------------------------------------------------
local api_url = string.format(
    "%s/api/v1/tool/action/get?device_id=%s&device_name=%s&device_boxname=%s&jwt=%s&action_type=remote_control&type=script",
    host, deviceID, deviceName, boxName, jwt
)

----------------------------------------------------------------
-- 🌐 CALL API FUNCTION
----------------------------------------------------------------
local function callAPI(url)
    local res = ""
    local c = curl.easy{
        url = url,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction = function(s)
            res = res .. s
            return #s
        end
    }

    local ok, err = pcall(function() c:perform() end)
    c:close()

    if not ok then
        toast("❌ API lỗi: " .. tostring(err))
        return nil
    end

    return res
end

----------------------------------------------------------------
-- 🚀 MAIN
----------------------------------------------------------------
toast("📡 Gọi API tạo thiết bị...")

local res = callAPI(api_url)
if not res then
    toast("❌ Không thể tạo thiết bị!")
    return
end

toast("✅ Thiết bị tạo thành công!")
log("📜 Server response:\n" .. res)

----------------------------------------------------------------
-- 📁 LƯU DEVICE.JSON
----------------------------------------------------------------
local f = io.open("device.json", "w")
if f then
    f:write(res)
    f:close()
end

toast("🎉 Creater.lua hoàn tất!")
