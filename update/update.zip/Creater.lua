----------------------------------------------------------------
-- 🌐 IBestCloud Device Creater (SAFE Version - No Script Overwrite)
-- By Mr.L (Optimized - Safe Mode)
----------------------------------------------------------------

local curl = require("cURL")

---------------------------------------------------------------
-- ⚙️ THÔNG SỐ CẤU HÌNH (CHỈ SỬA TẠI ĐÂY)
---------------------------------------------------------------
local jwt            = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJla2s4OSIsImxldmVsIjo5OSwiZnVsbF9uYW1lIjoiTG9uZyIsInVzZXJfaWQiOjEzLCJsYXN0X3RpbWVfcHciOjAsImlhdCI6MTc2MzUxNzAxNH0.qhs8jZQZsbnXfs5C44FBQapf5oyCl9BuNfnsVMu3qhM"
local device_id      = "K1"
local device_name    = "L1"
local device_boxname = "L1"

---------------------------------------------------------------
-- 📂 VỊ TRÍ FOLDER SCRIPT
---------------------------------------------------------------
local baseDir    = rootDir()
local fb_script  = baseDir .. "/FacebookAuto.lua"
local tt_script  = baseDir .. "/TikTokAuto.lua"

---------------------------------------------------------------
-- 🌍 API TẠO THIẾT BỊ
---------------------------------------------------------------
local api_url = string.format(
    "https://api.drxcloudphone.com/api/v1/tool/action/get?device_id=%s&device_name=%s&device_boxname=%s&jwt=%s&action_type=remote_control&type=script",
    device_id, device_name, device_boxname, jwt
)

local function callAPI(url)
    local response = ""
    local c = curl.easy{
        url = url,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction = function(s)
            response = response .. s
            return #s
        end
    }

    local ok, err = pcall(function() c:perform() end)
    c:close()

    if not ok then
        toast("❌ API lỗi: " .. tostring(err))
        return nil
    end

    return response
end

---------------------------------------------------------------
-- ✏️ UPDATE CONFIG SAFE (KHÔNG GHI ĐÈ CODE)
---------------------------------------------------------------
local function updateConfigOnly(path)
    local f = io.open(path, "r")
    if not f then
        toast("⚠️ Không tìm thấy script: " .. path)
        return false
    end

    local content = f:read("*a")
    f:close()

    -- Chỉ sửa đúng 5 dòng config
    content = content:gsub('local%s+jwt%s*=%s*".-"',            'local jwt = "' .. jwt .. '"')
    content = content:gsub('local%s+deviceID%s*=%s*".-"',       'local deviceID = "' .. device_id .. '"')
    content = content:gsub('local%s+device_id%s*=%s*".-"',      'local device_id = "' .. device_id .. '"')
    content = content:gsub('local%s+device_name%s*=%s*".-"',    'local device_name = "' .. device_name .. '"')
    content = content:gsub('local%s+device_boxname%s*=%s*".-"', 'local device_boxname = "' .. device_boxname .. '"')

    local fw = io.open(path, "w")
    fw:write(content)
    fw:close()

    toast("🔧 Đã cập nhật config: " .. path)
    return true
end

---------------------------------------------------------------
-- 🚀 MAIN
---------------------------------------------------------------
toast("📡 Đang gọi API tạo thiết bị...")

local res = callAPI(api_url)
if not res then
    toast("❌ Không thể tạo thiết bị.")
    return
end

toast("✅ Thiết bị đã tạo thành công!")

-- Update config một cách an toàn
updateConfigOnly(fb_script)
updateConfigOnly(tt_script)

toast("🎉 Hoàn tất – Đã cập nhật config mà KHÔNG ghi đè code!")
log("📜 Server response:\n" .. res)
