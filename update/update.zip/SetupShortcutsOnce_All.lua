--------------------------------------------------
-- SetupShortcutsOnce_All.lua
-- CUSTOMER FINAL VERSION
-- RUN ONCE PER DEVICE
--------------------------------------------------

local baseDir = rootDir()
local coreDir = baseDir .. "/core"
local FLAG    = coreDir .. "/.shortcuts_ready"

--------------------------------------------------
-- UTILS
--------------------------------------------------
local function fileExists(path)
    local f = io.open(path, "r")
    if f then f:close() return true end
    return false
end

local function sleep(s)
    usleep(s * 1000000)
end

local function tap(x, y)
    touchDown(1, x, y)
    usleep(80000)
    touchUp(1, x, y)
    usleep(500000)
end

--------------------------------------------------
-- SKIP IF DONE
--------------------------------------------------
if fileExists(FLAG) then
    toast("✅ Shortcuts ready – SKIP")
    return
end

toast("🔧 SETUP SHORTCUTS – FIRST TIME")

--------------------------------------------------
-- CONFIG (CHUẨN – KHÔNG NHẦM)
--------------------------------------------------
local AUTOSAVE_LINK =
"https://www.icloud.com/shortcuts/071a13e383434269a088533bf0d77595"

local DELETE_LINK =
"https://www.icloud.com/shortcuts/0588f74cf3794211a60940f643545619"

local ADD_X, ADD_Y = 374, 1265

--------------------------------------------------
-- RESET SHORTCUTS
--------------------------------------------------
appKill("com.apple.shortcuts")
sleep(1)

--------------------------------------------------
-- ADD AutoSaveVideo2
--------------------------------------------------
toast("➕ Add AutoSaveVideo2")
openURL(AUTOSAVE_LINK)
sleep(8)
tap(ADD_X, ADD_Y)
sleep(4)

--------------------------------------------------
-- ADD DeleteVideo
--------------------------------------------------
toast("➕ Add DeleteVideo")
openURL(DELETE_LINK)
sleep(8)
tap(ADD_X, ADD_Y)
sleep(4)

--------------------------------------------------
-- RUN DeleteVideo ONCE → TAP DELETE ALWAYS
--------------------------------------------------
toast("🗑️ Grant Delete Always permission")
openURL("shortcuts://run-shortcut?name=DeleteVideo")
sleep(2)

-- CHỐT 1 ĐIỂM DUY NHẤT
tap(370, 900)
sleep(1)

--------------------------------------------------
-- CREATE FLAG
--------------------------------------------------
local f = io.open(FLAG, "w")
if f then
    f:write("OK")
    f:close()
end

toast("🎉 SHORTCUTS READY – NEVER ASK AGAIN")
