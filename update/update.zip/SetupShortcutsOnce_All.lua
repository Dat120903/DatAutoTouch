--------------------------------------------------
-- SetupShortcutsOnce_All.lua
-- CUSTOMER VERSION – RUN ONCE PER DEVICE
-- AutoSaveVideo2 + DeleteVideo
-- Auto Allow Photos + Delete Always
--------------------------------------------------

local baseDir = rootDir()
local coreDir = baseDir .. "/core"
local FLAG    = coreDir .. "/.shortcuts_ready"

--------------------------------------------------
-- UTILS
--------------------------------------------------
local function fileExists(path)
    local f = io.open(path, "r")
    if f then f:close() return true end
    return false
end

local function createFlag()
    local f = io.open(FLAG, "w")
    if f then
        f:write("OK")
        f:close()
    end
end

local function sleep(s)
    usleep(s * 1000000)
end

local function tap(x, y)
    touchDown(1, x, y)
    usleep(80000)
    touchUp(1, x, y)
    usleep(500000)
end

local function urlEncode(str)
    return str:gsub("([^%w])", function(c)
        return string.format("%%%02X", string.byte(c))
    end)
end

--------------------------------------------------
-- SKIP IF READY
--------------------------------------------------
if fileExists(FLAG) then
    toast("✅ Shortcuts đã sẵn sàng – SKIP")
    return
end

toast("🔧 SETUP SHORTCUTS – FIRST & ONLY TIME")

--------------------------------------------------
-- CONFIG (CHUẨN)
--------------------------------------------------
local AUTOSAVE_LINK =
"https://www.icloud.com/shortcuts/0588f74cf3794211a60940f643545619"

local DELETE_LINK =
"https://www.icloud.com/shortcuts/071a13e383434269a088533bf0d77595"

local TEST_VIDEO =
"https://files.catbox.moe/3ur6ba.mp4"

-- toạ độ chuẩn đã chốt
local ADD_X, ADD_Y           = 374, 1265
local ALLOW_PHOTO_X, ALLOW_PHOTO_Y = 550, 280
local DELETE_ALWAYS_X, DELETE_ALWAYS_Y = 370, 900

--------------------------------------------------
-- RESET SHORTCUTS
--------------------------------------------------
appKill("com.apple.shortcuts")
sleep(1)

--------------------------------------------------
-- 1️⃣ ADD AutoSaveVideo2
--------------------------------------------------
toast("➕ Add AutoSaveVideo2")
openURL(AUTOSAVE_LINK)
sleep(8)
tap(ADD_X, ADD_Y)
sleep(4)

--------------------------------------------------
-- 2️⃣ AUTO ALLOW PHOTOS (AutoSave)
--------------------------------------------------
toast("🔐 Grant Photos Permission")

local encoded = urlEncode(TEST_VIDEO)
openURL("shortcuts://run-shortcut?name=AutoSaveVideo2&input=" .. encoded)

sleep(3)
tap(ALLOW_PHOTO_X, ALLOW_PHOTO_Y)
sleep(15)

--------------------------------------------------
-- 3️⃣ ADD DeleteVideo
--------------------------------------------------
toast("➕ Add DeleteVideo")
openURL(DELETE_LINK)
sleep(8)
tap(ADD_X, ADD_Y)
sleep(4)

--------------------------------------------------
-- 4️⃣ AUTO DELETE ALWAYS
--------------------------------------------------
toast("🗑️ Grant Delete Always")
openURL("shortcuts://run-shortcut?name=DeleteVideo")
sleep(2)
tap(DELETE_ALWAYS_X, DELETE_ALWAYS_Y)
sleep(1)

--------------------------------------------------
-- DONE
--------------------------------------------------
createFlag()
appKill("com.apple.shortcuts")
toast("🎉 SHORTCUTS READY – CUSTOMER SAFE")
